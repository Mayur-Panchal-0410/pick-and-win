import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';

function LoginModal() {
  const [show, setShow] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false); // State to toggle between Login and SignUp

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isSignUp) {
      // Handle sign-up logic here
      console.log('Sign Up - Email:', email);
      console.log('Sign Up - Password:', password);
    } else {
      // Handle login logic here
      console.log('Login - Email:', email);
      console.log('Login - Password:', password);
    }
    handleClose(); // Close modal after submission
  };

  const toggleForm = () => {
    setIsSignUp(!isSignUp); // Toggle between Login and Sign Up
    setEmail('');
    setPassword('');
  };

  return (
    <>
      <Button variant="success" onClick={handleShow}>
        {isSignUp ? 'Sign Up' : 'Login'}
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>{isSignUp ? 'Create an Account' : 'Login to Continue'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit}>
            <Form.Group controlId="formEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group controlId="formPassword">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </Form.Group>

            {isSignUp && (
              <Form.Group controlId="formConfirmPassword">
                <Form.Label>Confirm Password</Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Confirm your password"
                  required
                />
              </Form.Group>
            )}

            <Button variant="primary" type="submit" className="mt-3">
              {isSignUp ? 'Sign Up' : 'Login'}
            </Button>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="link" onClick={toggleForm}>
            {isSignUp ? 'Already have an account? Log in' : "Don't have an account? Sign up"}
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default LoginModal;
